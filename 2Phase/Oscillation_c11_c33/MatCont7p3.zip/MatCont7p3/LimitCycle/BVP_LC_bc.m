% -------------------------------------------------------------
% functions defining the BVP for limitcycles
% -------------------------------------------------------------

function bc = BVP_LC_bc(x0,x1)
bc = x0-x1;
