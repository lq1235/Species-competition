function initpath

    addpath('ComputationConfigurations');
    addpath('DataBrowser');
    addpath('SettingModel');
    addpath('DiagramOrganizer');
    addpath('GUIHomotopy')
end