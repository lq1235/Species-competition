function printconsole(varargin)
fprintf(varargin{:});
end
